# Inventory Management System
**FYP Title:** Sales and Inventory Management Web Application to Enhance Retail in Mobile Phone Store

start at login.aspx
username: admin
password: admin
